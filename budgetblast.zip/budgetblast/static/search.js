// search.js

// DOM Elements
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const categoryFilter = document.getElementById('categoryFilter');
const productGrid = document.getElementById('productGrid');

// Event Listeners
searchBtn.addEventListener('click', handleSearch);
searchInput.addEventListener('keyup', (e) => {
    if (e.key === 'Enter') {
        handleSearch();
    }
});
categoryFilter.addEventListener('change', handleSearch);

// Search functionality
function handleSearch() {
    const query = searchInput.value.toLowerCase();
    const category = categoryFilter.value;
    
    // Filter products based on search query and category
    const filteredProducts = products.filter(product => {
        const matchesQuery = product.name.toLowerCase().includes(query) ||
                           product.description.toLowerCase().includes(query);
        
        const matchesCategory = !category || product.category === category;
        
        return matchesQuery && matchesCategory;
    });
    
    displayProducts(filteredProducts);
}

// Display products in grid
function displayProducts(productsToShow) {
    productGrid.innerHTML = '';
    
    if (productsToShow.length === 0) {
        productGrid.innerHTML = `
            <div class="empty-message">
                <p>No products found matching your search criteria.</p>
            </div>
        `;
        return;
    }
    
    productsToShow.forEach(product => {
        const productCard = createProductCard(product);
        productGrid.appendChild(productCard);
    });
}

// Initial load - show all products
document.addEventListener('DOMContentLoaded', () => {
    displayProducts(products);
});