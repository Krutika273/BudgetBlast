// Auth state management
let isRegistering = false;

// DOM Elements
const loginForm = document.getElementById('loginForm');
const toggleRegister = document.getElementById('toggleRegister');
const nameGroup = document.getElementById('nameGroup');
const authContainer = document.getElementById('authContainer');
const navbar = document.querySelector('.navbar');
const logoutBtn = document.getElementById('logoutBtn');

// Check if user is logged in
function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
        showDashboard(user);
    }
}

// Event Listeners
loginForm.addEventListener('submit', handleAuth)