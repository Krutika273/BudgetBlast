// Product data
const products = [
    // Skincare
    {
        id: 1,
        name: "COSRX Advanced Snail 96 Mucin Power Essence",
        category: "Skincare",
        description: "A hydrating essence that helps repair and rejuvenate the skin.",
        priceNykaa: 1160,
        priceTira: 1150,
        image: "https://tse1.mm.bing.net/th?id=OIP.QhoWwRC0B3CRBOOMmPouLwHaHa&pid=Api"
    },
    {
        id: 2,
        name: "Plum 3% Niacinamide Alcohol-Free Toner",
        category: "Skincare",
        description: "A toner that reduces pores and blemishes, promoting bright skin.",
        priceNykaa: 382,
        priceTira: 375,
        image: "https://tse2.mm.bing.net/th?id=OIP.v1ixcHYolsH4vX-6PH_KCwHaHa&pid=Api"
    },
    {
        id: 3,
        name: "Cetaphil Gentle Skin Cleanser",
        category: "Skincare",
        description: "A gentle cleanser that keeps the skin moisturized and clean.",
        priceNykaa: 375,
        priceTira: 370,
        image: "https://tse2.mm.bing.net/th?id=OIP.2lfDyZ0E1WFvRl0gKGmfPwAAAA&pid=Api"
    },
    {
        id: 4,
        name: "Dr. Sheth’s Ceramide & Vitamin C Sunscreen",
        category: "Skincare",
        description: "A lightweight sunscreen with ceramides and Vitamin C for glowing skin.",
        priceNykaa: 499,
        priceTira: 495,
        image: "https://tse2.mm.bing.net/th?id=OIP.cthC2Hk2cCAGzzmFfmJZ-QHaEl&pid=Api"
    },
    {
        id: 5,
        name: "Laneige Lip Sleeping Mask Berry",
        category: "Skincare",
        description: "A leave-on lip mask that soothes and moisturizes overnight.",
        priceNykaa: 540,
        priceTira: 530,
        image: "https://tse3.mm.bing.net/th?id=OIP.TeQKbmu-WTjUvf9I86ol4gHaFM&pid=Api"
    },

    // Makeup
    {
        id: 6,
        name: "Maybelline New York Fit Me Matte + Poreless Foundation",
        category: "Makeup",
        description: "A foundation for normal to oily skin with a matte finish.",
        priceNykaa: 299,
        priceTira: 310,
        image: "https://tse3.mm.bing.net/th?id=OIP.TQavIMqpWZjzkgMDO4l36AHaHa&pid=Api"
    },
    {
        id: 7,
        name: "L'Oreal Paris Voluminous Lash Paradise Mascara",
        category: "Makeup",
        description: "A volumizing mascara for bold, dramatic lashes.",
        priceNykaa: 799,
        priceTira: 780,
        image: "https://tse1.mm.bing.net/th?id=OIP.2Zb5UpZ_YUPj4zT56NtPFgHaHb&pid=Api"
    },
    {
        id: 8,
        name: "Lakme 9 to 5 Primer + Matte Lip Color",
        category: "Makeup",
        description: "A matte lipstick with a built-in primer for smooth application.",
        priceNykaa: 550,
        priceTira: 540,
        image: "https://tse1.mm.bing.net/th?id=OIP.SRRPZcqzFZ1L-RSGNLF46wHaHa&pid=Api"
    },
    {
        id: 9,
        name: "Maybelline New York Fit Me Concealer",
        category: "Makeup",
        description: "A lightweight concealer for natural coverage.",
        priceNykaa: 475,
        priceTira: 470,
        image: "https://tse3.mm.bing.net/th?id=OIP.dvoR0Rs_kGNhOheKh_ngVQHaIe&pid=Api"
    },
    {
        id: 10,
        name: "L'Oreal Paris Infallible Pro-Matte Powder",
        category: "Makeup",
        description: "A long-lasting powder for shine-free skin.",
        priceNykaa: 699,
        priceTira: 690,
        image: "https://tse3.mm.bing.net/th?id=OIP.NstWOKBTN8iJaQIdVlx2MAHaHa&pid=Api"
    },

    // Haircare
    {
        id: 11,
        name: "Tresemme Keratin Smooth Shampoo",
        category: "Haircare",
        description: "A shampoo that tames frizz and adds shine.",
        priceNykaa: 199,
        priceTira: 195,
        image: "https://tse3.mm.bing.net/th?id=OIP.-ZT3nMcrykGqc8_Sxpu9LQHaHa&pid=Api"
    },
    {
        id: 12,
        name: "L'Oreal Paris Total Repair 5 Conditioner",
        category: "Haircare",
        description: "A conditioner that repairs and nourishes damaged hair.",
        priceNykaa: 180,
        priceTira: 175,
        image: "https://tse1.mm.bing.net/th?id=OIP.LeDXDcCT6ag0sAVkrmebYQHaHa&pid=Api"
    },
    {
        id: 13,
        name: "Dove Intense Repair Shampoo",
        category: "Haircare",
        description: "A shampoo that strengthens and repairs hair.",
        priceNykaa: 180,
        priceTira: 175,
        image: "https://tse4.mm.bing.net/th?id=OIP.V_fZZy46_4rNNBXJDf9dFwHaHa&pid=Api"
    },
    {
        id: 14,
        name: "Pantene Pro-V Hair Fall Control Conditioner",
        category: "Haircare",
        description: "A conditioner that reduces hair fall and nourishes hair.",
        priceNykaa: 180,
        priceTira: 175,
        image: "https://tse4.mm.bing.net/th?id=OIP.ypWBqaNE5vcLDPS_uIu1sQHaId&pid=Api"
    },
    {
        id: 15,
        name: "L'Oreal Paris Extraordinary Oil Serum",
        category: "Haircare",
        description: "A serum that transforms dull, dry hair to silky and shiny.",
        priceNykaa: 399,
        priceTira: 390,
        image: "https://tse4.mm.bing.net/th?id=OIP.J3K8BJ4C2AcTBEFYDqmMIAHaJ4&pid=Api"
    },

    // Fragrance
    {
        id: 16,
        name: "Chanel No. 5 Eau de Parfum",
        category: "Fragrance",
        description: "A classic fragrance with a blend of florals and aldehydes.",
        priceNykaa: 8500,
        priceTira: 8400,
        image: "https://tse2.mm.bing.net/th?id=OIP.k9u5L28ZbprIl_O2uh7YZwHaHa&pid=Api"
    },
    {
        id: 17,
        name: "Dior Sauvage Eau de Toilette",
        category: "Fragrance",
        description: "A fresh and spicy fragrance with a masculine allure.",
        priceNykaa: 7500,
        priceTira: 7400,
        image: "https://tse4.mm.bing.net/th?id=OIP.56TKoeji3BGRBSE_iJruBQHaHa&pid=Api"
    },
    {
        id: 18,
        name: "Yves Saint Laurent Black Opium Eau de Parfum",
        category: "Fragrance",
        description: "A captivating fragrance with notes of coffee and vanilla.",
        priceNykaa: 6500,
        priceTira: 6450,
        image: "https://tse2.mm.bing.net/th?id=OIP.X2sLedTzzxjPqj9UXpsn4AAAAA&pid=Api"
    },
    {
        id: 19,
        name: "Gucci Bloom Eau de Parfum",
        category: "Fragrance",
        description: "A rich, white floral fragrance inspired by gardens.",
        priceNykaa: 7000,
        priceTira: 6900,
        image: "https://tse3.mm.bing.net/th?id=OIP.jG4wbbKzDTdJSB7EQReN_gHaHa&pid=Api"
    },
    {
        id: 20,
        name: "Tom Ford Black Orchid Eau de Parfum",
        category: "Fragrance",
        description: "A luxurious and sensual fragrance with dark accords.",
        priceNykaa: 10000,
        priceTira: 9800,
        image: "https://tse2.mm.bing.net/th?id=OIP._luPJpBSdQAwTQzHTZsD8QHaKX&pid=Api"
    },

    // Bodycare
    {
        id: 21,
        name: "Nivea Nourishing Body Milk",
        category: "Bodycare",
        description: "A body milk for long-lasting moisture and smooth skin.",
        priceNykaa: 199,
        priceTira: 190,
        image: "https://tse1.mm.bing.net/th?id=OIP.Us9cPO_Vix2YeABlwoS2jwHaO0&pid=Api"
    },
    {
        id: 22,
        name: "Dove Deeply Nourishing Body Wash",
        category: "Bodycare",
        description: "A gentle body wash for soft and smooth skin.",
        priceNykaa: 199,
        priceTira: 190,
        image: "https://tse4.mm.bing.net/th?id=OIP.VLlX8vx7OdIoVggdNRc--gHaGU&pid=Api"
    },
    {
        id: 23,
        name: "The Body Shop Shea Body Butter",
        category: "Bodycare",
        description: "A rich body butter that intensely hydrates dry skin.",
        priceNykaa: 450,
        priceTira: 440,
        image: "https://tse1.mm.bing.net/th?id=OIP.DlPl3uM4LBG50pkxlVwR3QHaHa&pid=Api"
    },
    {
        id: 24,
        name: "Bath & Body Works Japanese Cherry Blossom Body Lotion",
        category: "Bodycare",
        description: "A body lotion with a classic, long-lasting floral scent.",
        priceNykaa: 595,
        priceTira: 580,
        image: "https://tse2.mm.bing.net/th?id=OIP.AqDnA99XAIQnETnBS46duwHaI8&pid=Api"
    },
    {
        id: 25,
        name: "Vaseline Intensive Care Deep Restore Body Lotion",
        category: "Bodycare",
        description: "A deeply moisturizing lotion for dry skin.",
        priceNykaa: 210,
        priceTira: 205,
        image: "https://tse3.mm.bing.net/th?id=OIP.NBu6SfbmCTNhA5QJVR8iHgHaHa&pid=Api"
    },


// Create product card
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const isWishlisted = getWishlist().includes(product.id);
    
    card.innerHTML = `
        <span class="category-label">${product.category}</span>
        <img src="${product.image}" alt="${product.name}">
        <div class="product-info">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <div class="price-comparison">
                <span>Nykaa: ₹${product.priceNykaa}</span>
                <span>Tira: ₹${product.priceTira}</span>
            </div>
            <button class="btn" onclick="toggleWishlist(${product.id})">
                ${isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
            </button>
        </div>
    `;
    return card;
}
];

// Wishlist functions
function getWishlist() {
    return JSON.parse(localStorage.getItem('wishlist') || '[]');
}

function setWishlist(wishlist) {
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
}

function toggleWishlist(productId) {
    const wishlist = getWishlist();
    const index = wishlist.indexOf(productId);
    
    if (index === -1) {
        wishlist.push(productId);
    } else {
        wishlist.splice(index, 1);
    }
    
    setWishlist(wishlist);
    
    // Refresh current view
    if (location.pathname.includes('desktop/budgetblast/templates/wishlist.html')) {
        displayWishlist();
    } else {
        handleSearch();
    }
}